"""Ponto de entrada da aplicação Valorant Stats Tracker."""

if __name__ == "__main__":
    print("Valorant Stats Tracker - projeto em desenvolvimento")
